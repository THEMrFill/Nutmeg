package com.nutmeg.philip.arnold.retrofit.data

data class Company(
    val bs: String,
    val catchPhrase: String,
    val name: String
)