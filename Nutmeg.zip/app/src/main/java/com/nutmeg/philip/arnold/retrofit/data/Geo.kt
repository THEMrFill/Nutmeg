package com.nutmeg.philip.arnold.retrofit.data

data class Geo(
    val lat: String,
    val lng: String
)